const $=s=>document.querySelector(s);
const esc=t=>String(t).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const KEY="rl_v2";let S={};
try{S=JSON.parse(localStorage.getItem(KEY))||{}}catch(e){S={}}
S.attempts=S.attempts||[];S.journal=S.journal||[];if(S.cur&&!S.cur.a)S.cur=null;S.unlocked=S.unlocked||1;S.done=S.done||[];
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}};
const hash=async p=>{try{const b=await crypto.subtle.digest("SHA-256",new TextEncoder().encode("rl:"+p));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("")}catch(e){return"p:"+p}};
const THEMES=[
{k:"default",n:"ลาเวนเดอร์",e:"💜",pv:"linear-gradient(135deg,#d6e0f8,#f7c98f)"},
{k:"forest",n:"ป่าเขียว",e:"🌲",pv:"linear-gradient(135deg,#d9e8d4,#e3c76a)",m:["🍃","🌿"]},
{k:"night",n:"ราตรี",e:"🌙",pv:"linear-gradient(135deg,#141a2b,#5d6aa8)",tc:"#fff",m:["✨","⭐"]},
{k:"fluffy",n:"ฟุ้งฟิ้ง",e:"☁️",pv:"linear-gradient(135deg,#ffc6e6,#d6ccff,#c8ecff)",m:["☁️","💖","✨","🫧","🌸"],v:"--bg:#ffe3f2;--card:#fff5fb;--ink:#6b3a62;--btn:#f59ccc;--acc:#ffd0e8;--line:#f7b6d9;--navbg:#ffe0f0"},
{k:"sakura",n:"ซากุระ",e:"🌸",pv:"linear-gradient(135deg,#fde6ec,#e68ba3)",m:["🌸","🌸","🌷"],v:"--bg:#fde6ec;--card:#fff4f6;--ink:#5a2a37;--btn:#e68ba3;--acc:#f9bfcd;--line:#efa9bb;--navbg:#fbd3dc"},
{k:"sea",n:"ทะเลคราม",e:"🌊",pv:"linear-gradient(135deg,#cdeefd,#3aa6c9)",m:["🫧","🐠","🫧","🐚"],v:"--bg:#cdeefd;--card:#eefaff;--ink:#12394d;--btn:#3aa6c9;--acc:#8fdcf0;--line:#7cc8e0;--navbg:#b7e6f6"},
{k:"sunset",n:"อาทิตย์อัสดง",e:"🌇",pv:"linear-gradient(135deg,#ffd9b5,#e5683c)",m:["✨","🕊️","☀️"],v:"--bg:#ffd9b5;--card:#fff0e0;--ink:#4a2316;--btn:#e5683c;--acc:#ffb36b;--line:#e89868;--navbg:#ffc58f"},
{k:"mint",n:"มินต์หวาน",e:"🍃",pv:"linear-gradient(135deg,#d4f5e6,#4cbf94)",m:["🍃","🫧","🌿"],v:"--bg:#d4f5e6;--card:#effcf6;--ink:#1d4636;--btn:#4cbf94;--acc:#9ce6c8;--line:#7fd3b0;--navbg:#bfeedb"},
{k:"retro",n:"เรโทรนีออน",e:"🕹️",pv:"linear-gradient(135deg,#1a1033,#ff3fa4,#00e5ff)",tc:"#fff",m:["⭐","👾","💿","✨"],v:"--bg:#1a1033;--card:#2b1b52;--ink:#f6e9ff;--btn:#ff3fa4;--acc:#7df9ff;--line:#7a4dd8;--navbg:#24154a"},
{k:"autumn",n:"ใบไม้ร่วง",e:"🍁",pv:"linear-gradient(135deg,#f6dcc0,#c26a2b)",m:["🍁","🍂","🍁"],v:"--bg:#f6dcc0;--card:#fff1e0;--ink:#4a2a14;--btn:#c26a2b;--acc:#f0b15f;--line:#d49a62;--navbg:#eac394"}];
(()=>{const s=document.createElement("style");s.textContent=THEMES.filter(t=>t.v).map(t=>`:root[data-skin="${t.k}"]{${t.v}}`).join("");document.head.appendChild(s)})();
function fx(){const f=$("#fx");f.innerHTML="";const t=THEMES.find(x=>x.k===S.skin);if(!t||!t.m)return;for(let i=0;i<16;i++){const s=document.createElement("span");s.textContent=t.m[i%t.m.length];s.style.cssText=`left:${(i*37)%100}%;font-size:${14+(i*7)%18}px;animation-duration:${9+(i*5)%11}s;animation-delay:-${(i*3)%12}s`;f.appendChild(s)}}
function skin(){const r=document.documentElement;S.skin&&S.skin!=="default"?r.setAttribute("data-skin",S.skin):r.removeAttribute("data-skin");fx()}skin();
function setSkin(k){S.skin=k;save();skin();render()}

/* ---------- ภาพประกอบ SVG ---------- */
const sv=(b,bg="#cfe6f3")=>`<svg class="art" viewBox="0 0 200 120" preserveAspectRatio="xMidYMid slice" role="img" aria-hidden="true"><rect width="200" height="120" fill="${bg}"/>${b}</svg>`;
const ART={
mt:()=>sv(`<path d="M0 96L38 36 64 66 108 20 148 62 172 42 200 90V120H0Z" fill="#b9ad98"/><path d="M0 100Q50 84 100 98T200 94V120H0Z" fill="#5d8a3c"/><ellipse cx="70" cy="106" rx="42" ry="8" fill="#1f8a82"/>`),
hero:()=>sv(`<path d="M0 90L30 40 58 70 100 14 142 66 170 36 200 84V120H0Z" fill="#b9ad98"/><path d="M0 98Q50 80 100 96T200 92V120H0Z" fill="#4f8434"/><path d="M0 108Q50 98 100 108T200 104V120H0Z" fill="#1f8a82"/><path d="M10 88Q100 60 190 88" stroke="#a63d33" stroke-width="3" fill="none"/><path d="M10 92Q100 66 190 92" stroke="#8a342c" stroke-width="5" fill="none"/>`,"#bfe0f4"),
naga:()=>sv(`<path d="M0 96L40 40 70 70 110 24 150 64 180 44 200 90V120H0Z" fill="#9db2a0"/><rect y="104" width="200" height="16" fill="#5d8a3c"/><path d="M96 106Q70 92 100 80T100 58" stroke="#8b5b4b" stroke-width="14" fill="none" stroke-linecap="round"/><ellipse cx="100" cy="40" rx="22" ry="26" fill="#5c3b3d"/><ellipse cx="100" cy="48" rx="9" ry="12" fill="#9e6d5a"/>`,"#7fbfe8"),
bud:()=>sv(`<path d="M0 100L50 40 90 70 140 30 200 96V120H0Z" fill="#b9ad98"/><rect width="200" height="20" y="100" fill="#5d8a3c"/><path d="M92 100V54Q100 40 108 54V100Z" fill="#e3ae30"/><circle cx="100" cy="42" r="8" fill="#e3ae30"/><circle cx="100" cy="42" r="15" fill="none" stroke="#f3c85a" stroke-width="2"/>`),
shrine:()=>sv(`<rect y="96" width="200" height="24" fill="#8fae6a"/><path d="M50 60L100 30 150 60Z" fill="#b4472f"/><rect x="60" y="60" width="6" height="36" fill="#eadfcc"/><rect x="134" y="60" width="6" height="36" fill="#eadfcc"/><rect x="66" y="76" width="68" height="20" fill="#7a3a2a"/>`,"#e7edf5"),
quarry:()=>sv(`<path d="M0 120V80H40V60H80V40H120V60H160V84H200V120Z" fill="#a7a095"/><path d="M0 120V96H50V78H90V60H130V78H170V100H200V120Z" fill="#c9c2b3"/><circle cx="162" cy="24" r="12" fill="#f5d36a"/>`,"#e6ddd0"),
cave:()=>sv(`<path d="M0 120V50Q60 0 120 10 170 14 200 50V120Z" fill="#9a8f7c"/><path d="M70 120V80Q100 40 130 80V120Z" fill="#2c2620"/><rect y="108" width="200" height="12" fill="#5d8a3c"/>`,"#cfe0d8"),
boat:()=>sv(`<rect y="70" width="200" height="50" fill="#7d6a3b"/><path d="M40 84Q100 108 160 84L150 96H50Z" fill="#6b4a2a"/><path d="M84 66L100 52 116 66Z" fill="#e8d26a"/><rect x="70" y="86" width="10" height="6" fill="#d9443a"/><circle cx="130" cy="82" r="6" fill="#f2a63a"/>`,"#bfe0f4"),
jar:()=>sv(`<path d="M70 20H130Q134 30 148 56 156 90 130 108H70Q44 90 52 56 66 30 70 20Z" fill="#7a4a2a"/><path d="M60 62Q80 52 100 66T140 60" stroke="#e3ae30" stroke-width="4" fill="none"/>`,"#efe3d2"),
puppet:()=>sv(`<rect x="20" y="10" width="160" height="100" fill="#f3e8cf"/><path d="M80 100V60L70 40 90 46 100 24 110 46 130 40 120 60V100Z" fill="#2a2018"/><circle cx="100" cy="20" r="7" fill="#2a2018"/>`,"#3a2a1e")
};

const PH={
 "login": "assets/images/login.jpg",
 "lake": "assets/images/lake.webp",
 "shrine": "assets/images/shrine.jpg",
 "naga": "assets/images/naga.jpg",
 "bud": "assets/images/bud.jpg",
 "mascot": "assets/images/mascot.jpg"
};const im=(k,alt)=>`<img class="art" src="${PH[k]}" alt="${alt}">`;
ART.naga=()=>im("naga","รูปปั้นงูเห่า");ART.bud=()=>im("bud","พระพุทธรูปปางลีลา");ART.shrine=()=>im("shrine","ศาลเจ้าพ่อเขางู");ART.lake=()=>im("lake","สะพานและทะเลสาบอุทยานหินเขางู");
const PIN=`<svg class="pin" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22s7-6.2 7-12a7 7 0 10-14 0c0 5.8 7 12 7 12z" fill="none" stroke="#e53935" stroke-width="2"/><circle cx="12" cy="10" r="2.6" fill="none" stroke="#e53935" stroke-width="2"/></svg>`;
/* ---------- พื้นแผนที่ภูมิประเทศ ---------- */
const MAPBG=(()=>{let s=7;const R=()=>(s=s*16807%2147483647)/2147483647,mid=(a,b)=>[(a[0]+b[0])/2,(a[1]+b[1])/2];
const blob=(cx,cy,rx,ry,j)=>{const n=14,p=[...Array(n)].map((_,i)=>{const a=i/n*6.283,k=1+(R()-.5)*j;return[+(cx+Math.cos(a)*rx*k).toFixed(2),+(cy+Math.sin(a)*ry*k).toFixed(2)]});let d="M"+mid(p[n-1],p[0]).join(" ");p.forEach((q,i)=>{d+="Q"+q.join(" ")+" "+mid(q,p[(i+1)%n]).map(v=>v.toFixed(2)).join(" ")});return d+"Z"};
const hills=[[14,16,13,6],[88,40,12,9],[12,64,11,8],[82,90,13,6],[50,50,9,5]];
let ct="";hills.forEach(([x,y,rx,ry])=>{for(let i=1;i<=6;i++)ct+=`<path d="${blob(x,y,rx*i/6*1.6,ry*i/6*1.6,.18)}"/>`});
let gr="";for(let i=10;i<100;i+=10)gr+=`M${i} 0V100M0 ${i}H100`;
return`<svg class="mbg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><defs><pattern id="fo" width="2.4" height="2.4" patternUnits="userSpaceOnUse"><circle cx="1.2" cy="1.2" r=".45" fill="#6f8c58"/></pattern></defs><rect width="100" height="100" fill="#e6e0c8"/><path d="${blob(16,38,15,10,.3)}" fill="#cfdab0"/><path d="${blob(16,38,15,10,.3)}" fill="url(#fo)"/><path d="${blob(86,16,14,9,.3)}" fill="#cfdab0"/><path d="${blob(86,16,14,9,.3)}" fill="url(#fo)"/><path d="${blob(60,80,16,8,.3)}" fill="#d8e0b8"/><path d="${blob(60,80,16,8,.3)}" fill="url(#fo)"/><path d="${blob(78,92,13,5,.25)}" fill="#a9c6d3"/><g fill="none" stroke="#a8946f" stroke-width=".22" opacity=".6">${ct}</g><path d="${gr}" stroke="#8a7a5a" stroke-width=".1" opacity=".22" fill="none"/><path d="M-5 63C20 56 45 72 70 63S105 58 110 66" fill="none" stroke="#9cbccb" stroke-width="3.2" stroke-linecap="round"/><path d="M-5 63C20 56 45 72 70 63S105 58 110 66" fill="none" stroke="#c4dbe5" stroke-width="1.4" stroke-linecap="round"/></svg>`})();
const CMP=`<svg class="cmp" viewBox="0 -8 60 68" aria-hidden="true"><circle cx="30" cy="30" r="25" fill="#efe9d2" fill-opacity=".8" stroke="#6b5a40" stroke-width="1.2"/><path d="M30 8L35 30 30 52 25 30Z" fill="#6b5a40"/><path d="M8 30L30 25 52 30 30 35Z" fill="#a39274"/><text x="30" y="-1" text-anchor="middle" font-size="10" font-weight="700" fill="#4a3b28">N</text></svg>`;
/* ---------- ข้อมูลด่านและคำถาม (เฉลยเก็บเฉพาะในข้อมูล c) ---------- */
const Q=[
{t:"งูเห่า",clue:"รูปปั้นงูเห่า อุทยานหินเขางู",art:"naga",k:{h:"4 เรื่องน่ารู้ “งูเห่า” หน้าอุทยานหินเขางู ราชบุรี",b:["ชื่อเรียก: ชาวบ้านนิยมเรียกรูปปั้นงูเห่าองค์นี้ว่า “องค์พ่อใหญ่”","ปีที่สร้าง: สร้างเสร็จเมื่อกุมภาพันธ์ 2562 เพื่อเป็นแลนด์มาร์กใหม่ของเขางู","จุดเด่น: เป็นรูปปั้นงูเห่าขนาดใหญ่ที่พ่นน้ำออกจากปากได้ และเป็นจุดถ่ายรูปยอดฮิต","ที่มาความเชื่อ: สร้างตามชื่อ “เขางู” ที่มีตำนานเล่าขานเกี่ยวกับพญางูใหญ่และตำนานพื้นบ้านเรื่องพญางู"]},q:"รูปปั้นรูปนี้มีความหมายว่าอย่างไร?",o:["หมายถึงงูเห่า","หมายถึงตำนานความเชื่อ","หมายถึงนิทานชาวนากับงูเห่า","หมายถึงที่นี่มีงูขาย"],c:1},
{t:"พระพุทธรูปปางลีลา",clue:"พระพุทธรูปปางลีลา อุทยานหินเขางู",art:"bud",k:{h:"พระพุทธรูปองค์ใหญ่ที่แกะสลักบนหน้าผาของอุทยานหินเขางู มีชื่อเรียกว่า “พระพุทธรูปปางลีลา อุทยานหินเขางู”",b:["ความสูง: ประมาณ 4 เมตร แกะสลักเป็นภาพนูนสูง ตัวองค์พระนูนเด่นออกจากหน้าผา","ลักษณะศิลปะ: ปางลีลา (ท่าก้าวเดินจงกรม) ศิลปะแบบทวารวดี","การก่อสร้าง: เริ่มจากการวางศิลาฤกษ์เมื่อ พ.ศ. 2510 และแล้วเสร็จสมบูรณ์ใน พ.ศ. 2512"]},q:"ขนาดความสูงของพระมีขนาดเท่าใด?",o:["นูนต่ำ ความสูง 4 เมตร","นูนสูง ความสูง 4 เมตร","นูนต่ำ ความสูง 3 เมตร","นูนสูง ความสูง 7 เมตร"],c:1},
{t:"ศาลเจ้าพ่อเขางู",clue:"ศาลเจ้าพ่อเขางู",art:"shrine",k:{h:"ศาลเจ้าพ่อเขางู",b:["ที่ตั้ง: บริเวณด้านหน้าทางเข้าอุทยานหินเขางู อำเภอเมือง จังหวัดราชบุรี","ความสำคัญ: เป็นสิ่งศักดิ์สิทธิ์คู่เมืองที่ชาวราชบุรีและนักท่องเที่ยวให้ความเคารพกราบไหว้","ประวัติ: ไม่ปรากฏหลักฐานแน่ชัดว่าสร้างเมื่อใด แต่มีบันทึกว่าได้รับการบูรณะครั้งใหญ่ใน พ.ศ. 2513 จึงสันนิษฐานว่าศาลตั้งอยู่กับเขางูมานานแล้ว"]},q:"การบูรณะเกิดขึ้นเมื่อใด?",o:["ไม่มีการบูรณะใดเกิดขึ้น","เกิดขึ้นในปี ค.ศ. 2513","เกิดขึ้นในปี พ.ศ. 2513","เกิดขึ้นในสมัยธนบุรี"],c:2},
{t:"อุทยานหินเขางู",clue:"อุทยานหินเขางู",art:"lake",k:{h:"เขางู อายุราว 250 ล้านปี",b:["ยุคโบราณ: เป็นภูเขาหินปูนธรรมชาติที่เคยอยู่ใต้ทะเลเมื่อหลายร้อยล้านปีก่อน","สงครามเก้าทัพ (พ.ศ. 2328): พื้นที่ราบรอบเขาเรียกว่า “ทุ่งเขางู” เคยเป็นสมรภูมิสำคัญที่ไทยตั้งรับกองทัพพม่า","ยุคโรงโม่หิน: เคยถูกสัมปทานระเบิดหินปูน ทำให้ภูเขาแหว่งเว้าเป็นหน้าผาชันอย่างที่เห็นในปัจจุบัน","สมัยทวารวดี (พุทธศตวรรษที่ 12-16): เป็นพุทธสถานในถ้ำที่เก่าแก่ที่สุดแห่งหนึ่งในไทย มีถ้ำฤๅษี ถ้ำฝาโถ ถ้ำจีน"]},q:"ข้อใดคือบทบาทสำคัญของ “เขางู” ในช่วงพุทธศตวรรษที่ 12-16 (สมัยทวารวดี)?",o:["เป็นสมรภูมิรบหลักในสงครามเก้าทัพ","เป็นที่ตั้งของพระพุทธรูปปางลีลาองค์ใหญ่ที่สุดในโลก","เป็นแหล่งสัมปทานระเบิดหินปูนแห่งแรกของประเทศ","เป็นศาสนสถานในถ้ำที่เก่าแก่ที่สุดแห่งหนึ่งในไทย"],c:3}
];
const kHtml=k=>`<p><b>${k.h}</b></p><ul class="kl">${k.b.map(x=>`<li>${x}</li>`).join("")}</ul>`;
const LEARN=Q.map(q=>({t:q.t,a:q.art,k:q.k}));
const HS=[
{n:1,p:[6.5,3.4,-1.1],t:"พระพุทธรูปปางลีลา",d:"ในโมเดลนี้พระพุทธรูปสีทองตั้งอยู่กลางลานหน้าภูเขา เป็นจุดเด่นที่ผู้มาเยือนเห็นก่อนใคร"},
{n:2,p:[6,2.4,1.2],t:"รูปปั้นงูเห่า",d:"ประติมากรรมงูใหญ่บนฐานหินสื่อถึงชื่อ “เขางู” และความเชื่อของคนในพื้นที่"},
{n:3,p:[-1.5,1.6,.7],t:"สะพานแขวน",d:"สะพานสีแดงทอดข้ามทะเลสาบ เป็นจุดเดินชมวิวและถ่ายภาพ"},
{n:4,p:[-2.5,.4,1.5],t:"ทะเลสาบ",d:"พื้นที่เหมืองเก่าที่ฟื้นฟูแล้วกลายเป็นแหล่งน้ำและสวนสาธารณะ"},
{n:5,p:[2.8,2,5.2],t:"ซุ้มประตูทางเข้า",d:"จุดเริ่มต้นของการเดินเที่ยวในอุทยาน ก่อนเข้าสู่ลานกว้างและภูเขาหินปูน"},
{n:6,p:[-3.1,7,-4.7],t:"เทือกเขาหินปูน",d:"เขาหินปูนเคยถูกระเบิดและย่อยหิน ปัจจุบันกลายเป็นฉากหลังของอุทยาน"}
];

/* ---------- ระบบ ---------- */
let view="login",sel=null,lp=0,sub="menu",msg="";
const score=a=>a.answers.reduce((n,x,i)=>n+(x===Q[i].c?1:0),0);
const fmt=ts=>new Date(ts).toLocaleString("th-TH",{dateStyle:"medium",timeStyle:"short"});
function go(v){view=v;sel=null;if(v==="settings")sub="menu";if(v==="learn")lp=lp||0;render()}
function render(){
  const lg=!!S.in&&!!S.user;if(!lg&&view!=="login")view="login";
  $("#hb").hidden=!lg;$("#nav").hidden=!lg;
  const t=view==="3d";$("#v3d").hidden=!t;$("#main").hidden=t;window.__on3d=t;
  const TM={quiz:"home",result:"home","3d":"learn",act:"learn",match:"learn",guess:"learn",journal:"settings"};document.querySelectorAll("nav [data-t]").forEach(b=>b.classList.toggle("on",b.dataset.t===(TM[view]||view)));
  if(t){init3d();return}
  $("#main").innerHTML=(V[view]||V.home)();scrollTo(0,0);
}
const V={};
let fg=false;
V.login=()=>`<div class="lg"><h1>Ratchaburi</h1><img class="lgi" src="${PH.login}" alt=""><div class="sheet">${fg?`<p><b>ลืมรหัสผ่าน</b><br>บัญชีนี้เก็บอยู่ในเครื่องนี้เท่านั้น การตั้งรหัสใหม่จึงต้องล้างบัญชีและข้อมูลทั้งหมดในเครื่อง (คะแนน บันทึก ความคืบหน้า) แล้วสร้างบัญชีใหม่</p><button class="lgb" onclick="resetAcct()">ยืนยัน ล้างข้อมูลและสร้างบัญชีใหม่</button><button class="lgb" onclick="fg=false;render()">ยกเลิก</button>`:`${msg?`<div class="msg no">${msg}</div>`:""}<div class="fld"><span>👤</span><input id="u" aria-label="ชื่อผู้ใช้" placeholder="ชื่อผู้ใช้" autocomplete="username" value="${S.user?esc(S.user.name):""}" ${S.user?"readonly":""}></div><div class="fld"><span>🔒</span><input id="p" type="password" aria-label="รหัสผ่าน" placeholder="${S.user?"รหัสผ่าน":"ตั้งรหัสผ่าน (อย่างน้อย 4 ตัว)"}" autocomplete="current-password"></div><button class="lgb" onclick="login()">${S.user?"เข้าสู่ระบบ":"สร้างบัญชีและเข้าสู่ระบบ"}</button>${S.user?`<button class="lgb sm" onclick="fg=true;msg='';render()">ลืมรหัสผ่าน?</button>`:""}`}</div></div>`;
function resetAcct(){S={attempts:[],journal:[],unlocked:1,done:[],skin:S.skin};save();fg=false;msg="";render()}
async function login(){const u=$("#u").value.trim(),p=$("#p").value;msg="";
  if(!S.user){if(!u||p.length<4){msg="กรอกชื่อผู้ใช้ และรหัสผ่านอย่างน้อย 4 ตัว";return render()}S.user={name:u,h:await hash(p)}}
  else if(await hash(p)!==S.user.h){msg="รหัสผ่านไม่ถูกต้อง";return render()}
  S.in=true;save();go("home")}
V.home=()=>{const c=S.cur,u=S.unlocked||1,dn=S.done||[],cnt=dn.filter(Boolean).length,st=k=>k>=u?"lock":(c&&c.a[k]!==null)||dn[k]?"done":"open",
P=[[24,78],[76,50],[24,24]],lab=["งูเห่า","พระพุทธรูปปางลีลา","ศาลเจ้าพ่อเขางู"],pr=[0,.22,.5,.76,1][Math.min(cnt,4)],ans=c?c.a.filter(x=>x!==null).length:0,np=[...Array(u).keys()].find(k=>!c||c.a[k]===null);
const node=k=>{const s=st(k),[x,y]=P[k];return`<button class="nd ${s}" style="left:${x}%;top:${y}%" onclick="goStage(${k})" aria-label="ด่าน ${k+1}: ${Q[k].t}">${PIN}<span class="ci"><img src="${PH[Q[k].art]}" alt="">${s==="done"?"<i>✓</i>":s==="lock"?"<i>🔒</i>":""}</span><small>${k+1}. ${lab[k]}</small></button>`};
const D="M50 100C50 92 24 90 24 78C24 62 76 66 76 50C76 36 24 40 24 24C24 10 50 12 50 0";
return`<div class="map"><button class="nd top ${st(3)}" onclick="goStage(3)" aria-label="ด่าน 4: ${Q[3].t}">${PIN}<img class="mh" src="${PH.lake}" alt="สะพานอุทยานหินเขางู"><small>4. อุทยานหินเขางู</small></button><div class="route">${MAPBG}<svg class="trail" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><path d="${D}" pathLength="100" fill="none" stroke="#5b4636" stroke-width="1" stroke-dasharray="1.2 1.6" stroke-linecap="round"/><path d="${D}" pathLength="100" fill="none" stroke="#2f6b45" stroke-width="1.5" stroke-linecap="round" stroke-dasharray="${pr*100} 200"/></svg><div class="cart"><b>แผนที่เส้นทางเรียนรู้</b><br>อุทยานหินเขางู · ราชบุรี</div>${CMP}${[0,1,2].map(node).join("")}<div class="flag"><i></i>จุดเริ่มต้น</div></div><div class="mhead"><b>สวัสดี ${esc(S.user.name)}</b><br>เดินตามเส้นทางจากล่างขึ้นบน 1 ด่านต่อ 1 ข้อ ตอบเสร็จด่านถัดไปปลดล็อคทันที<br><span class="muted">ปลดล็อคแล้ว ${u} จาก ${Q.length} ด่าน · รอบนี้ตอบแล้ว ${ans}/${Q.length} ข้อ</span></div><div id="toast" class="msg no" role="status" hidden></div>${c&&c.k!==null?`<button class="b" onclick="go('quiz')">เล่นต่อ ด่านที่ ${c.k+1}</button>`:np!==undefined?`<button class="b" onclick="goStage(${np})">เล่นด่านที่ ${np+1}</button>`:`<button class="b" onclick="retry()">เริ่มรอบใหม่</button>`}${ans>0&&ans<Q.length?`<button class="b alt" onclick="retry()">เริ่มรอบใหม่</button>`:""}</div>`};
function goStage(k){const u=S.unlocked||1,t=$("#toast");let m="";
 if(k>=u)m="ด่านนี้ยังล็อกอยู่ ตอบด่านก่อนหน้าให้เสร็จก่อน";
 else{if(!S.cur)S.cur=newRun();const c=S.cur;if(c.k===k)return go("quiz");if(c.k!==null)m="กำลังเล่นด่านที่ "+(c.k+1)+" อยู่ จบด่านนี้ก่อน";else if(c.a[k]!==null)m="ด่านนี้ตอบในรอบนี้แล้ว ไปด่านอื่น หรือกด “เริ่มรอบใหม่”";else{c.k=k;c.phase="lock";save();return go("quiz")}}
 if(t){t.hidden=false;t.textContent=m}}
V.learn=()=>{const l=LEARN[lp];return`<h2>ความรู้</h2><div class="row"><button class="b alt" onclick="go('3d')">🗻 ห้องเรียน 3 มิติ</button><button class="b alt" onclick="go('act')">🎮 กิจกรรม</button></div><div class="vb">${LEARN.map((x,k)=>`<button class="${k===lp?"on":""}" onclick="lp=${k};render()">${k+1}. ${x.t}</button>`).join("")}</div><div class="card"><div class="frame">${ART[l.a]()}</div><h2>${l.t}</h2>${kHtml(l.k)}<div class="muted">หัวข้อ ${lp+1} จาก ${LEARN.length}</div><div class="row"><button class="b alt" ${lp?"":"disabled"} onclick="lp--;render()">ย้อนกลับ</button><button class="b alt" ${lp<LEARN.length-1?"":"disabled"} onclick="lp++;render()">ถัดไป</button></div><button class="b" onclick="lessonQuiz()">ทำแบบทดสอบท้ายบท</button></div>`};
function lessonQuiz(){const k=lp;if(k<(S.unlocked||1)){goStage(k);if(view!=="quiz")go("home")}else go("home")}
function newRun(){return{a:[null,null,null,null],k:null,phase:null}}
function startRun(){if(!S.cur)S.cur=newRun();save();go("home")}
function retry(){S.cur=newRun();save();go("home")}
V.quiz=()=>{const c=S.cur;if(!c||c.k===null){view="home";return V.home()}const i=c.k,q=Q[i],ans=c.a[i],dn=c.a.filter(x=>x!==null).length,
  pg=`<div class="muted">ด่าน ${i+1} จาก ${Q.length}</div><div class="bar"><i style="width:${dn/Q.length*100}%"></i></div>`;
  if(c.phase==="lock")return`${pg}<div class="pill">ปลดล็อคด่าน ${i+1}</div><div class="card"><div class="frame">${ART[q.art]()}</div><div class="cl" style="margin-top:10px">ชุดคำถามที่ ${i+1}</div><h2 class="cl">“${q.clue}”</h2><button class="b" onclick="ph('know')">ถัดไป</button></div>`;
  if(c.phase==="know")return`${pg}<div class="pill">ความรู้</div><div class="card"><div class="frame">${ART[q.art]()}</div>${kHtml(q.k)}<button class="b" onclick="ph('q')">ถัดไป</button></div>`;
  if(c.phase==="q")return`<div class="hero">${ART[q.art]()}<span class="lbl">คำถาม</span></div>${pg}<div class="card qc"><h2 class="cl">${q.q}</h2>${q.o.map((o,k)=>`<button class="opt ${sel===k?"sel":""}" onclick="sel=${k};render()">${o}</button>`).join("")}<button class="b" ${sel===null?"disabled":""} onclick="confirmA()">ยืนยันคำตอบ</button></div>`;
  const ok=ans===q.c;
  return`<div class="hero">${ART[q.art]()}<div class="pill ttl">${ok?"คำตอบถูกต้อง":"คำตอบผิดนะ"}</div></div>${pg}<div class="card qc"><div class="msg ${ok?"ok":"no"}">${ok?"ถูกต้อง ได้ 1 คะแนน":"ยังไม่ถูก ไม่ได้คะแนนข้อนี้"}<br>เฉลย: ${q.o[q.c]}</div>${kHtml(q.k)}<div class="muted">${i<Q.length-1?"ผ่านด่านนี้แล้ว ด่านถัดไปปลดล็อคเรียบร้อย":"ผ่านครบทุกด่านแล้ว"}</div><button class="b" onclick="next()">${c.a.every(x=>x!==null)?"ดูสรุปคะแนน":"กลับไปแผนที่"}</button></div>`};
function ph(p){if(S.cur&&S.cur.k!==null){S.cur.phase=p;sel=null;save();render()}}
function confirmA(){const c=S.cur;if(!c||c.k===null||c.phase!=="q"||sel===null||c.a[c.k]!==null)return;const k=c.k;c.a[k]=sel;c.phase="fb";sel=null;S.done[k]=true;S.unlocked=Math.max(S.unlocked||1,Math.min(Q.length,k+2));save();render()}
function next(){const c=S.cur;if(!c||c.phase!=="fb")return;if(c.a.every(x=>x!==null)){const a={id:Date.now(),answers:c.a.slice()};S.attempts.push(a);S.last=a.id;S.cur=null;save();return go("result")}c.k=null;c.phase=null;save();go("home")}
V.result=()=>{const a=S.attempts.find(x=>x.id===S.last);if(!a){return`<div class="card">ยังไม่มีผลคะแนน ทำแบบทดสอบให้ครบทุกด่านก่อน<button class="b" onclick="startRun()">เริ่มทำแบบทดสอบ</button></div>`}
  const r=score(a),w=Q.length-r,p=Math.round(r/Q.length*100),C=2*Math.PI*52,m=p>=80?"ยอดเยี่ยม คุณรู้จักเขางูได้ดีมาก":p>=50?"ดี ลองทบทวนบทเรียนอีกครั้งเพื่อคะแนนที่สูงขึ้น":"ไม่เป็นไร กลับไปอ่านบทเรียนแล้วลองใหม่ได้เลย";
  return`<div class="card"><h2 style="text-align:center">คะแนนของคุณ</h2><svg viewBox="0 0 120 120" style="width:170px;display:block;margin:0 auto"><circle cx="60" cy="60" r="52" fill="none" stroke="var(--line)" stroke-width="12"/><circle cx="60" cy="60" r="52" fill="none" stroke="var(--ok)" stroke-width="12" stroke-linecap="round" stroke-dasharray="${C*p/100} ${C}" transform="rotate(-90 60 60)"/><text x="60" y="68" text-anchor="middle" font-size="26" font-weight="800" fill="currentColor">${p}%</text></svg><div class="big">${r} / ${Q.length}</div><div style="text-align:center">คะแนน</div><div class="row" style="margin-top:10px"><div class="msg ok">ตอบถูก ${r} ข้อ</div><div class="msg no">ตอบผิด ${w} ข้อ</div></div><p style="text-align:center">จากทั้งหมด ${Q.length} ข้อ คิดเป็น ${p}%<br>${m}</p><button class="b" onclick="go('home')">กลับไปหน้าหลัก</button><button class="b alt" onclick="retry()">ทำแบบทดสอบอีกครั้ง</button></div>`};
V.score=()=>{const A=S.attempts;return`<h2>บันทึกคะแนน</h2>${A.length?[...A].reverse().map((a,k)=>{const r=score(a),p=Math.round(r/Q.length*100);return`<div class="card"><b>รอบที่ ${A.length-k}</b> <span class="muted">${fmt(a.id)}</span><div class="bar"><i style="width:${p}%"></i></div>${r}/${Q.length} คะแนน (${p}%) · ถูก ${r} ผิด ${Q.length-r}</div>`}).join(""):`<div class="card">ยังไม่มีผลคะแนน ผลจะแสดงหลังทำแบบทดสอบครบทุกด่าน<button class="b" onclick="startRun()">เริ่มทำแบบทดสอบ</button></div>`}`};
V.journal=()=>`<h2>บันทึกการเดินทาง</h2><div class="card"><textarea id="jt" rows="3" placeholder="วันนี้ได้เรียนรู้อะไรเกี่ยวกับเขางู?"></textarea><button class="b" onclick="addJ()">บันทึก</button></div>${S.journal.length?[...S.journal].reverse().map(j=>`<div class="card"><span class="muted">${fmt(j.id)}</span><p>${esc(j.t)}</p><button class="b alt" onclick="delJ(${j.id})">ลบ</button></div>`).join(""):`<div class="card muted">ยังไม่มีบันทึก เขียนข้อความแรกได้เลย</div>`}`;
function addJ(){const t=$("#jt").value.trim();if(!t)return;S.journal.push({id:Date.now(),t});save();render()}
function delJ(id){S.journal=S.journal.filter(j=>j.id!==id);save();render()}
const MASCOT=`<svg viewBox="0 0 100 100" style="width:110px;display:block;margin:0 auto"><circle cx="50" cy="50" r="44" fill="#7fa57a"/><circle cx="36" cy="44" r="9" fill="#fff"/><circle cx="64" cy="44" r="9" fill="#fff"/><circle cx="37" cy="45" r="4" fill="#222"/><circle cx="65" cy="45" r="4" fill="#222"/><path d="M34 66Q50 78 66 66" stroke="#222" stroke-width="3" fill="none"/><path d="M26 28Q50 6 74 28Z" fill="#c9a66c"/></svg>`;
V.settings=()=>{const back=`<button class="b alt" onclick="sub='menu';msg='';render()">ย้อนกลับ</button>`,m=msg?`<div class="msg ${msg.startsWith("✓")?"ok":"no"}">${msg}</div>`:"";
  if(sub==="account")return`<h2>บัญชี</h2><div class="card"><div class="masbox"><img src="${PH.mascot}" alt="มาสคอตปลานักสำรวจ"></div><p>ชื่อผู้ใช้: <b>${esc(S.user.name)}</b></p><p>รหัสผ่าน: ••••••</p>${back}</div>`;
  if(sub==="name")return`<h2>เปลี่ยนชื่อ</h2><div class="card">${m}<label>ชื่อใหม่</label><input id="nn" value="${esc(S.user.name)}"><button class="b" onclick="chName()">บันทึกชื่อ</button>${back}</div>`;
  if(sub==="pw")return`<h2>เปลี่ยนรหัสผ่าน</h2><div class="card">${m}<label>รหัสผ่านเดิม</label><input id="p0" type="password"><label>รหัสผ่านใหม่</label><input id="p1" type="password"><label>ใส่รหัสอีกครั้ง</label><input id="p2" type="password"><button class="b" onclick="chPw()">ยืนยันการเปลี่ยนรหัสผ่าน</button>${back}</div>`;
  if(sub==="theme")return`<h2>เปลี่ยนธีม</h2><div class="card"><div class="tg">${THEMES.map(t=>`<button class="th ${(S.skin||"default")===t.k?"cur":""}" style="background:${t.pv};color:${t.tc||"#2b2b2b"}" onclick="setSkin('${t.k}')" aria-label="ธีม ${t.n}"><span>${t.e}</span><b>${t.n}</b></button>`).join("")}</div>${back}</div>`;
  return`<h2>ตั้งค่า</h2><div class="card"><button class="b alt" onclick="sub='account';render()">บัญชี</button><button class="b alt" onclick="sub='name';render()">เปลี่ยนชื่อ</button><button class="b alt" onclick="sub='pw';render()">เปลี่ยนรหัสผ่าน</button><button class="b alt" onclick="sub='theme';render()">เปลี่ยนธีม</button><button class="b alt" onclick="go('journal')">บันทึกการเดินทาง</button><button class="b alt" onclick="S.in=false;save();go('login')">ออกจากระบบ</button></div>`};
function chName(){const n=$("#nn").value.trim();if(!n){msg="กรอกชื่อ";return render()}S.user.name=n;save();msg="✓ เปลี่ยนชื่อแล้ว";render()}
async function chPw(){const a=$("#p0").value,b=$("#p1").value,c=$("#p2").value;
  if(await hash(a)!==S.user.h)msg="รหัสผ่านเดิมไม่ถูกต้อง";else if(b.length<4)msg="รหัสใหม่ต้องมีอย่างน้อย 4 ตัว";else if(b===a)msg="รหัสใหม่ต้องไม่ซ้ำกับรหัสเดิม";else if(b!==c)msg="รหัสทั้งสองครั้งไม่ตรงกัน";else{S.user.h=await hash(b);save();msg="✓ เปลี่ยนรหัสผ่านแล้ว"}render()}

/* ---------- กิจกรรม ---------- */
const PAIRS=[["พระพุทธรูปปางลีลา","พุทธลักษณะก้าวเดิน"],["ศาลเจ้าพ่อเขางู","ที่กราบไหว้ของคนท้องถิ่น"],["เหมืองหินเก่า","ฟื้นฟูเป็นอุทยาน"],["ทวารวดี","ศิลปะโบราณในถ้ำ"]];
const PL=["ตลาดน้ำดำเนินสะดวก","อุทยานหินเขางู","โอ่งมังกรราชบุรี","หนังใหญ่วัดขนอน"],GQ=[["boat",0],["mt",1],["jar",2],["puppet",3]];
let M=null,G=null;const shuf=a=>a.map(x=>[Math.random(),x]).sort((x,y)=>x[0]-y[0]).map(x=>x[1]);
V.act=()=>`<h2>กิจกรรมการเรียนรู้</h2><div class="card"><b>เกมจับคู่</b><p>จับคู่สถานที่กับคำอธิบายให้ถูกต้อง</p><button class="b" onclick="M={r:shuf([0,1,2,3]),l:null,d:[],x:0};go('match')">เล่นเกมจับคู่</button></div><div class="card"><b>ทายสถานที่จากภาพ</b><p>ดูภาพแล้วเลือกชื่อสถานที่ 4 ข้อ</p><button class="b" onclick="G={i:0,s:0,a:null};go('guess')">เล่นเกมทายภาพ</button></div><div class="card"><b>ทบทวนความรู้</b><p>อ่านบทเรียนอีกครั้งก่อนทำแบบทดสอบ</p><button class="b alt" onclick="go('learn')">ไปที่บทเรียน</button></div>`;
V.match=()=>{const fin=M.d.length===4;return`<h2>เกมจับคู่</h2><div class="row"><div>${[0,1,2,3].map(k=>`<button class="opt ${M.d.includes(k)?"ok":M.l===k?"sel":""}" ${M.d.includes(k)?"disabled":""} onclick="mL(${k})">${PAIRS[k][0]}</button>`).join("")}</div><div>${M.r.map(k=>`<button class="opt ${M.d.includes(k)?"ok":""}" id="r${k}" ${M.d.includes(k)?"disabled":""} onclick="mR(${k})">${PAIRS[k][1]}</button>`).join("")}</div></div>${fin?`<div class="msg ok">จับคู่ครบแล้ว ผิด ${M.x} ครั้ง</div>`:`<div class="muted">เลือกชื่อทางซ้ายก่อน แล้วเลือกคำอธิบายทางขวา</div>`}<button class="b alt" onclick="go('act')">กลับไปหน้ากิจกรรม</button>`};
function mL(k){M.l=k;render()}
function mR(k){if(M.l===null)return;if(M.l===k){M.d.push(k);M.l=null;render()}else{M.x++;M.l=null;render();const e=$("#r"+k);e&&e.classList.add("shake")}}
V.guess=()=>{if(G.i>=GQ.length)return`<h2>ทายสถานที่</h2><div class="card"><div class="big">${G.s} / ${GQ.length}</div><p style="text-align:center">ตอบถูก ${G.s} ข้อ จาก ${GQ.length} ข้อ</p><button class="b" onclick="G={i:0,s:0,a:null};render()">เล่นอีกครั้ง</button><button class="b alt" onclick="go('act')">กลับไปหน้ากิจกรรม</button></div>`;
  const [a,c]=GQ[G.i];return`<h2>ทายสถานที่จากภาพ (${G.i+1}/${GQ.length})</h2><div class="card">${ART[a]()}<p><b>ภาพนี้คือที่ไหน?</b></p>${PL.map((o,k)=>`<button class="opt ${G.a===null?"":k===c?"ok":k===G.a?"no":""}" ${G.a===null?"":"disabled"} onclick="gA(${k})">${o}</button>`).join("")}${G.a===null?"":`<button class="b" onclick="G.i++;G.a=null;render()">ถัดไป</button>`}</div>`};
function gA(k){if(G.a!==null)return;G.a=k;if(k===GQ[G.i][1])G.s++;render()}

/* ---------- 3 มิติ ---------- */
let m3=false,vec=null;
function init3d(){
  setTimeout(()=>dispatchEvent(new Event("resize")),30);if(m3)return;
  const st=$("#stage");
  if(typeof THREE==="undefined"||!THREE.OrbitControls)return fail3("โหลด Three.js ไม่สำเร็จ ตรวจสอบอินเทอร์เน็ตแล้วลองอีกครั้ง");
  try{mount3d();m3=true;vec=new THREE.Vector3();
    $("#hsl").innerHTML=HS.map(h=>`<button aria-label="${h.t}" onclick="hsGo(${h.n-1})">${h.n}</button>`).join("");
    const bs=$("#hsl").children;
    window.__hs=cam=>{const w=st.clientWidth,hh=st.clientHeight;HS.forEach((h,k)=>{vec.set(...h.p).project(cam);const b=bs[k];if(vec.z>1){b.style.display="none"}else{b.style.display="";b.style.left=(vec.x*.5+.5)*w+"px";b.style.top=(-vec.y*.5+.5)*hh+"px"}})};
  }catch(e){fail3("อุปกรณ์นี้แสดงโมเดล 3 มิติไม่ได้ (WebGL ไม่พร้อมใช้งาน)")}
}
function fail3(t){$("#stage").innerHTML=`<div class="err">${t}<button class="b" onclick="location.reload()">โหลดใหม่</button></div>`}
function hsGo(k){const h=HS[k],T=window.__scene.THREE;window.__scene.flyTo(new T.Vector3(h.p[0]+3,h.p[1]+3,h.p[2]+9),new T.Vector3(h.p[0],Math.max(h.p[1]-2,.3),h.p[2]));$("#hsInfo").innerHTML=`<b>${h.n}. ${h.t}</b><br>${h.d}`}
render();
