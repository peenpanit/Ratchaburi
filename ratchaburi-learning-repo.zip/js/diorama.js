/* โมเดล 3 มิติอุทยานหินเขางู (Three.js r128) — ฟังก์ชัน mount3d() ถูกเรียกจาก app.js */
function mount3d(){const STAGE=document.getElementById("stage"),W=()=>STAGE.clientWidth||320,H=()=>STAGE.clientHeight||360;
const A = 11, B = 7.5;
function rnd(s){return function(){s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const R = rnd(11), rr = (a,b)=>a+(b-a)*R();
const n2 = (x,y)=>Math.sin(x*1.7+y*2.3)*.5+Math.sin(x*3.1-y*1.3+1.7)*.3+Math.sin(x*5.3+y*4.1)*.2;
const edge = (th,f)=>{const m=1+.035*Math.sin(3*th+1)+.02*Math.cos(5*th);return [A*f*m*Math.cos(th),B*f*m*Math.sin(th)]};
const rho = (x,z)=>Math.hypot(x/A,z/B);

// ---------- renderer / scene ----------
const renderer = new THREE.WebGLRenderer({antialias:true,alpha:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.setSize(W(),H());
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
STAGE.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(38, W()/H(), .1, 300);
const HOME = {p:new THREE.Vector3(-7,13,21), t:new THREE.Vector3(0,.5,0)};
camera.position.copy(HOME.p);
const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.target.copy(HOME.t); controls.enableDamping = true; controls.dampingFactor = .08;
controls.minDistance = 7; controls.maxDistance = 55; controls.maxPolarAngle = Math.PI/2 - .03; controls.autoRotateSpeed = 1.4;

scene.add(new THREE.HemisphereLight(0xffffff,0x9a8a6a,.62));
const sun = new THREE.DirectionalLight(0xfff0d8,.85);
sun.position.set(-11,19,13); sun.castShadow = true;
sun.shadow.mapSize.set(2048,2048); Object.assign(sun.shadow.camera,{left:-17,right:17,top:17,bottom:-17,near:1,far:60});
sun.shadow.bias = -.0006; scene.add(sun);

// ---------- helpers ----------
const mc = {};
const mat = (c,r=.85,m=0)=>{const k=c+"_"+r+"_"+m;return mc[k]||(mc[k]=new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m}))};
const sh = m=>{m.castShadow=true;m.receiveShadow=true;return m};
function bx(p,w,h,d,c,x,y,z,ry){const m=sh(new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(c)));m.position.set(x,y,z);if(ry)m.rotation.y=ry;p.add(m);return m}
function cyl(p,rt,rb,h,c,x,y,z,seg=14,mm){const m=sh(new THREE.Mesh(new THREE.CylinderGeometry(rt,rb,h,seg),mm||mat(c)));m.position.set(x,y,z);p.add(m);return m}
function tex(w,h,draw,rep){const c=document.createElement("canvas");c.width=w;c.height=h;draw(c.getContext("2d"),w,h);const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;if(rep)t.repeat.set(rep[0],rep[1]);t.anisotropy=4;return t}
const palette=(ctx,w,h,cols,n,r0,r1)=>{for(let i=0;i<n;i++){ctx.fillStyle=cols[(R()*cols.length)|0];ctx.beginPath();ctx.arc(R()*w,R()*h,rr(r0,r1),0,7);ctx.fill()}};

// ---------- island base ----------
const grassTex = tex(512,512,(c,w,h)=>{c.fillStyle="#6e8b3b";c.fillRect(0,0,w,h);palette(c,w,h,["#7c9a45","#5f7e32","#8a8f4a","#6a5a3a","#789a4c"],900,3,14)},[.18,.18]);
const soilTex = tex(512,256,(c,w,h)=>{const g=c.createLinearGradient(0,0,0,h);g.addColorStop(0,"#5e3f27");g.addColorStop(.5,"#4b311e");g.addColorStop(1,"#3a2616");c.fillStyle=g;c.fillRect(0,0,w,h);
  for(let i=0;i<14;i++){c.fillStyle="rgba("+(R()<.5?"30,18,8":"120,86,56")+","+rr(.08,.2)+")";c.fillRect(0,R()*h,w,rr(2,9))}
  palette(c,w,h,["rgba(140,105,75,.55)","rgba(35,22,12,.5)","rgba(170,150,120,.45)"],700,1,4)},[.12,.6]);
const ipts=[];for(let i=0;i<140;i++){const p=edge(i/140*Math.PI*2,1);ipts.push(new THREE.Vector2(p[0],-p[1]))}
const ig = new THREE.ExtrudeGeometry(new THREE.Shape(ipts),{depth:1.7,bevelEnabled:false,steps:1});
ig.rotateX(-Math.PI/2); ig.translate(0,-1.7,0);
const island = new THREE.Mesh(ig,[new THREE.MeshStandardMaterial({map:grassTex,roughness:1}),new THREE.MeshStandardMaterial({map:soilTex,roughness:1})]);
island.receiveShadow = true; island.castShadow = true; scene.add(island);
// floor shadow
const fl = new THREE.Mesh(new THREE.PlaneGeometry(60,46),new THREE.MeshBasicMaterial({transparent:true,depthWrite:false,map:tex(256,256,(c,w,h)=>{const g=c.createRadialGradient(w/2,h/2,10,w/2,h/2,w/2);g.addColorStop(0,"rgba(30,30,30,.45)");g.addColorStop(.55,"rgba(30,30,30,.18)");g.addColorStop(1,"rgba(30,30,30,0)");c.fillStyle=g;c.fillRect(0,0,w,h)})}));
fl.material.map.wrapS=fl.material.map.wrapT=THREE.ClampToEdgeWrapping;fl.rotation.x=-Math.PI/2;fl.position.y=-1.72;scene.add(fl);

// ---------- lake ----------
const LK = {x:-1.6,z:.6,a:6.3,b:3};
function lakeShape(k){const p=[];for(let i=0;i<90;i++){const t=i/90*Math.PI*2;p.push(new THREE.Vector2((LK.x+LK.a*k*Math.cos(t)*(1+.07*Math.sin(2*t+.5))),-(LK.z+LK.b*k*Math.sin(t)*(1+.1*Math.sin(3*t)))))}return new THREE.Shape(p)}
const bank = new THREE.Mesh(new THREE.ShapeGeometry(lakeShape(1.07)),mat(0x9a8a66,1));bank.rotation.x=-Math.PI/2;bank.position.y=.012;bank.receiveShadow=true;scene.add(bank);
const wTex = tex(256,256,(c,w,h)=>{const g=c.createLinearGradient(0,0,w,h);g.addColorStop(0,"#0f7f78");g.addColorStop(1,"#0a6a68");c.fillStyle=g;c.fillRect(0,0,w,h);
  for(let i=0;i<160;i++){c.strokeStyle="rgba(190,245,235,"+rr(.05,.16)+")";c.lineWidth=rr(1,2.5);const x=R()*w,y=R()*h,l=rr(8,26);c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+l/2,y-3,x+l,y);c.stroke()}},[.22,.22]);
const water = new THREE.Mesh(new THREE.ShapeGeometry(lakeShape(1)),new THREE.MeshStandardMaterial({map:wTex,roughness:.18,metalness:.15}));
water.rotation.x=-Math.PI/2;water.position.y=.03;water.receiveShadow=true;scene.add(water);

// ---------- roads ----------
function ribbon(fn,n,w,y,color,r=.9){const pos=[],idx=[];for(let i=0;i<=n;i++){const t=i/n,p=fn(t),q=fn(Math.min(1,t+.003)),q0=fn(Math.max(0,t-.003));let tx=q[0]-q0[0],tz=q[1]-q0[1];const l=Math.hypot(tx,tz)||1;tx/=l;tz/=l;
  pos.push(p[0]-tz*w/2,y,p[1]+tx*w/2,p[0]+tz*w/2,y,p[1]-tx*w/2);if(i<n){const k=i*2;idx.push(k,k+2,k+1,k+1,k+2,k+3)}}
  const g=new THREE.BufferGeometry();g.setAttribute("position",new THREE.Float32BufferAttribute(pos,3));g.setIndex(idx);g.computeVertexNormals();
  const m=new THREE.Mesh(g,mat(color,r));m.receiveShadow=true;scene.add(m);return m}
const ringFn = t=>edge(-.35+t*(Math.PI+.7),.88);
ribbon(ringFn,160,1.05,.012,0xbcb3a3);ribbon(ringFn,160,.72,.02,0x6f6f72);ribbon(ringFn,160,.035,.03,0xd9bd4b);
const spPts=[[4.3,6.1],[4.6,4.9],[5.4,3.95],[6.0,3.0]];
const spl = new THREE.SplineCurve(spPts.map(p=>new THREE.Vector2(p[0],p[1])));
const spFn = t=>{const p=spl.getPoint(t);return [p.x,p.y]};
ribbon(spFn,30,.9,.015,0xbcb3a3);ribbon(spFn,30,.62,.022,0x6f6f72);
// parking
const park=new THREE.Group();park.position.set(3.7,0,3.9);scene.add(park);bx(park,1.7,.03,1.2,0x77777a,0,.02,0).receiveShadow=true;
for(let i=-3;i<=3;i++)bx(park,.025,.01,.5,0xeeeeee,i*.23,.04,-.25);

// ---------- mountains ----------
const MT = [ // cx, cz, r, h, zScale, seed
  [-6.6,-3.9,2.6,5.2,.82,1],[-3.1,-4.7,3.0,7.0,.78,2.3],[2.5,-4.9,2.6,5.4,.8,3.7],[6.8,-3.6,2.8,6.3,.85,5.1]];
function mFactor(a,t,s){return {k:1+(n2(a*3+s,t*5)*.16+n2(a*7,t*11+s)*.07)*(1-t*.3),dy:n2(a*4+s,t*3)*.25*(1-t)}}
const mRad = (r,t)=>r*Math.pow(1-t,1.35)+.12*t;
const smooth=(a,b,x)=>{x=Math.min(1,Math.max(0,(x-a)/(b-a)));return x*x*(3-2*x)};
const cA=new THREE.Color(0xb8ad9b),cB=new THREE.Color(0xc99466),cC=new THREE.Color(0xdcd5c6),cG=new THREE.Color(0x4a7733),cD=new THREE.Color(0x35602b),tc=new THREE.Color();
MT.forEach(([cx,cz,r,h,sz,s])=>{
  const g=new THREE.CylinderGeometry(.12,r,h,56,26,true);g.translate(0,h/2-.2,0);
  const P=g.attributes.position,cols=[];
  for(let i=0;i<P.count;i++){const x=P.getX(i),y=P.getY(i),z=P.getZ(i);const t=Math.min(1,Math.max(0,(y+.2)/h)),a=Math.atan2(z,x),f=mFactor(a,t,s),rd=mRad(r,t)*f.k;
    P.setXYZ(i,Math.cos(a)*rd,y+f.dy,Math.sin(a)*rd);
    const nn=n2(a*5+s,t*9),patch=n2(a*9+s,t*14+s)>.5?.65:0;
    const gw=Math.max(Math.min(1,Math.max(0,1-(t-.1-.1*nn)/.22)),patch*(1-t*.8));
    tc.copy(cA).lerp(cB,Math.min(1,Math.max(0,.5+.5*Math.sin(y*4.5+nn*3))*.7)).lerp(cC,smooth(.55,.95,t));
    tc.lerp(cD.clone().lerp(cG,.5+.5*nn),gw);cols.push(tc.r,tc.g,tc.b)}
  g.setAttribute("color",new THREE.Float32BufferAttribute(cols,3));g.computeVertexNormals();
  const m=sh(new THREE.Mesh(g,new THREE.MeshStandardMaterial({vertexColors:true,roughness:.95,flatShading:true,side:THREE.DoubleSide})));
  m.position.set(cx,0,cz);m.scale.z=sz;scene.add(m)});

// ---------- trees ----------
const TREES=[];
const near=(x,z,px,pz,d)=>Math.hypot(x-px,z-pz)<d;
function okGround(x,z){
  const q=rho(x,z);if(q>.95||(q>.82&&q<.95&&z>-3.5))return false;
  if(Math.pow((x-LK.x)/(LK.a*1.2),2)+Math.pow((z-LK.z)/(LK.b*1.3),2)<1)return false;
  for(const [cx,cz,r,,sz] of MT)if(Math.pow((x-cx)/(r*.95),2)+Math.pow((z-cz)/(r*sz*.95),2)<1)return false;
  if(x>4&&x<8.2&&z>-.9&&z<2.4)return false;
  if(near(x,z,6.5,-1.1,1.3)||near(x,z,8,2.5,.9))return false;
  if(Math.abs(x-2.8)<3.4&&z>4.6&&z<6)return false;
  if(x>2.7&&x<4.7&&z>3.2&&z<4.6)return false;
  for(let i=0;i<=12;i++){const p=spl.getPoint(i/12);if(near(x,z,p.x,p.y,.8))return false}
  for(const p of [[-8.1,1.3],[1.2,4.4],[-1.6,5.5],[-6.2,4.3],[-4.3,5],[-6.9,-.4],[4,1.8]])if(near(x,z,p[0],p[1],.9))return false;
  return true}
let tries=0;while(TREES.length<190&&tries++<6000){const x=rr(-10,10),z=rr(-7,7);if(okGround(x,z))TREES.push([x,0,z,rr(.9,1.7)])}
MT.forEach(([cx,cz,r,h,sz,s],mi)=>{for(let i=0;i<120;i++){const t=rr(.03,.6),a=R()*6.283,f=mFactor(a,t,s),rd=mRad(r,t)*f.k*.98;
  TREES.push([cx+Math.cos(a)*rd,t*h-.2+f.dy-.05,cz+Math.sin(a)*rd*sz,rr(.6,1.15)*(1-t*.5)])}});
(function(){const n=TREES.length,FC=[0x2f5d27,0x3d7330,0x4f8434,0x66963c,0x2a4c2a,0x5a8a3a].map(c=>new THREE.Color(c));
  const tr=new THREE.InstancedMesh(new THREE.CylinderGeometry(.035,.06,.5,5),mat(0x5b4129),n);
  const fo=new THREE.InstancedMesh(new THREE.IcosahedronGeometry(.26,1),new THREE.MeshStandardMaterial({roughness:.9,flatShading:true}),n*2);
  const d=new THREE.Object3D(),col=new THREE.Color();
  TREES.forEach((t,i)=>{const s=t[3];d.rotation.set(0,0,0);d.position.set(t[0],t[1]+.25*s,t[2]);d.scale.set(s,s,s);d.updateMatrix();tr.setMatrixAt(i,d.matrix);
    for(let k=0;k<2;k++){d.position.set(t[0]+(R()-.5)*.12*s,t[1]+(.5+k*.3)*s,t[2]+(R()-.5)*.12*s);const q=s*(k?.8:1.15);d.scale.set(q,q*.9,q);d.rotation.set(0,R()*6,0);d.updateMatrix();
      fo.setMatrixAt(i*2+k,d.matrix);fo.setColorAt(i*2+k,col.copy(FC[(R()*FC.length)|0]).offsetHSL(0,0,(R()-.5)*.06))}});
  tr.castShadow=fo.castShadow=true;fo.receiveShadow=true;scene.add(tr,fo)})();
// flowers
(function(){const n=90,im=new THREE.InstancedMesh(new THREE.SphereGeometry(.055,6,5),new THREE.MeshStandardMaterial({roughness:.8}),n),d=new THREE.Object3D(),cs=[0xe46a8b,0xf2c744,0xffffff,0xd9443a,0xb77ad8];let i=0,k=0;
  while(i<n&&k++<3000){const x=rr(-9,9),z=rr(1,6.5);if(!okGround(x,z)||rho(x,z)>.8)continue;d.position.set(x,.08,z);d.updateMatrix();im.setMatrixAt(i,d.matrix);im.setColorAt(i,new THREE.Color(cs[(R()*5)|0]));i++}
  im.count=i;scene.add(im)})();
function palm(x,z,s=1){const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(s);const t=cyl(g,.035,.07,1.15,0x7a5a3a,0,.57,0,6);t.rotation.z=.12;
  for(let i=0;i<7;i++){const L=new THREE.Group();L.position.set(.13,1.15,0);L.rotation.y=i/7*6.283;const l=sh(new THREE.Mesh(new THREE.ConeGeometry(.09,.75,4),mat(0x3f7f2c)));l.scale.z=.25;l.rotation.z=-1.25;l.position.set(.3,-.05,0);L.add(l);g.add(L)}scene.add(g)}
[[1.2,5.45],[4.9,5.4],[-1.0,6.0],[7.4,4.0],[-3.6,5.3],[0.4,5.5]].forEach(p=>palm(p[0],p[1],rr(.85,1.1)));
// rocks
[[-6.2,4.3,.62],[-4.3,5.0,.8]].forEach(([x,z,s])=>{const g=new THREE.DodecahedronGeometry(s,1),P=g.attributes.position;for(let i=0;i<P.count;i++){const k=1+.18*n2(P.getX(i)*3,P.getZ(i)*3+P.getY(i));P.setXYZ(i,P.getX(i)*k,P.getY(i)*k*.85,P.getZ(i)*k)}g.computeVertexNormals();
  const m=sh(new THREE.Mesh(g,new THREE.MeshStandardMaterial({color:0xb4a88f,roughness:.95,flatShading:true})));m.position.set(x,s*.5,z);scene.add(m)});
// fence along front edge
(function(){const pts=[];for(let i=0;i<=70;i++){const p=edge(-.25+i/70*(Math.PI+.5),.955);pts.push(new THREE.Vector3(p[0],.2,p[1]))}
  const rail=sh(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts),140,.012,4),mat(0x7a5a3a)));scene.add(rail);
  const im=new THREE.InstancedMesh(new THREE.BoxGeometry(.045,.3,.045),mat(0x7a5a3a),pts.length),d=new THREE.Object3D();
  pts.forEach((p,i)=>{d.position.set(p.x,.15,p.z);d.updateMatrix();im.setMatrixAt(i,d.matrix)});im.castShadow=true;scene.add(im)})();

// ---------- bridge ----------
(function(){const Ab=new THREE.Vector3(-6.9,.3,-.4),Bb=new THREE.Vector3(4,.3,1.8),mid=Ab.clone().add(Bb).multiplyScalar(.5);
  const dir=Bb.clone().sub(Ab),L=Math.hypot(dir.x,dir.z),ang=Math.atan2(dir.z,dir.x),perp=new THREE.Vector3(-dir.z/L,0,dir.x/L);
  const curve=new THREE.QuadraticBezierCurve3(Ab,new THREE.Vector3(mid.x,.3+1.2,mid.z),Bb);
  const N=70;for(let i=0;i<N;i++){const p=curve.getPoint(i/N),q=curve.getPoint((i+1)/N),m=sh(new THREE.Mesh(new THREE.BoxGeometry(.42,.05,p.distanceTo(q)+.02),mat(i%2?0x9c3b32:0x8a342c)));
    m.position.copy(p.clone().add(q).multiplyScalar(.5));m.lookAt(q);scene.add(m)}
  const towerTop=2.25;
  [-1,1].forEach(s=>{
    const rp=[];for(let i=0;i<=60;i++)rp.push(curve.getPoint(i/60).add(perp.clone().multiplyScalar(.21*s)).add(new THREE.Vector3(0,.2,0)));
    scene.add(sh(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(rp),90,.018,5),mat(0xa63d33))));
    const ta=Ab.clone().add(perp.clone().multiplyScalar(.5*s)),tb=Bb.clone().add(perp.clone().multiplyScalar(.5*s));ta.y=tb.y=towerTop;
    const cab=new THREE.QuadraticBezierCurve3(ta,new THREE.Vector3(mid.x+perp.x*.5*s,.15,mid.z+perp.z*.5*s),tb);
    scene.add(new THREE.Mesh(new THREE.TubeGeometry(cab,60,.014,4),mat(0x7a4a44)));
    const hp=[];for(let i=1;i<20;i++){const u=i/20,c=cab.getPoint(u),d=curve.getPoint(u).add(perp.clone().multiplyScalar(.21*s));hp.push(c,d.add(new THREE.Vector3(0,.2,0)))}
    scene.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(hp),new THREE.LineBasicMaterial({color:0x6b4a44})))});
  [Ab,Bb].forEach(P=>{[-1,1].forEach(s=>{const c=P.clone().add(perp.clone().multiplyScalar(.5*s));const m=bx(scene,.2,2.5,.2,0xeadfcc,c.x,1.1,c.z,-ang);bx(scene,.3,.2,.3,0xc9bda8,c.x,-.1,c.z,-ang)});
    const b=bx(scene,.34,.3,1.4,0xc0392b,P.x,2.3,P.z,-ang),b2=bx(scene,.55,.1,1.7,0x9c2f26,P.x,2.5,P.z,-ang);
    cyl(scene,.7,.8,.5,0x8d8a82,P.x,.0,P.z,20)})
})();

// ---------- buddha & plaza ----------
const gold = new THREE.MeshStandardMaterial({color:0xe3ae30,roughness:.32,metalness:.55,emissive:0x4a3205});
const gold2 = new THREE.MeshStandardMaterial({color:0xb9791a,roughness:.4,metalness:.5,emissive:0x2e1c02});
const dark = new THREE.MeshStandardMaterial({color:0x3a2a10,roughness:.6});
function limb(g,a,b,r,m){const d=new THREE.Vector3().subVectors(b,a),len=d.length();const c=sh(new THREE.Mesh(new THREE.CylinderGeometry(r,r,len,8),m));c.position.copy(a).add(b).multiplyScalar(.5);c.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());g.add(c);return c}
(function(){const g=new THREE.Group();g.position.set(6.5,0,-1.1);g.scale.setScalar(1.1);scene.add(g);
  bx(g,2.4,.2,1.3,0x9c968a,0,.1,0);bx(g,1.5,.16,.9,0xc9c2b3,0,.28,0);
  cyl(g,.42,.5,.1,0,0,.41,0,24,gold2);
  for(let i=0;i<16;i++){const L=new THREE.Group();L.rotation.y=i/16*6.283;const pt=sh(new THREE.Mesh(new THREE.ConeGeometry(.09,.3,4),gold));pt.scale.z=.4;pt.position.set(.44,.55,0);pt.rotation.z=-.45;L.add(pt);g.add(L)}
  const pr=[[0,.45],[.4,.47],[.38,.62],[.34,1.0],[.27,1.5],[.22,1.85],[.25,2.15],[.31,2.38],[.27,2.55],[.1,2.68],[.085,2.8],[0,2.82]].map(q=>new THREE.Vector2(q[0],q[1]));
  const body=sh(new THREE.Mesh(new THREE.LatheGeometry(pr,28),gold));body.scale.z=.62;g.add(body);
  const hem=new THREE.Mesh(new THREE.TorusGeometry(.38,.025,6,28),gold2);hem.rotation.x=Math.PI/2;hem.position.y=.64;hem.scale.set(1,.62,1);g.add(hem);
  const sash=bx(g,.1,1.15,.03,0xb9791a,-.02,1.9,.2);sash.rotation.z=.5;sash.material=gold2;
  const hd=sh(new THREE.Mesh(new THREE.SphereGeometry(.19,20,14),gold));hd.position.y=2.98;hd.scale.set(1,1.1,.95);g.add(hd);
  for(let i=0;i<16;i++){const a=i/16*6.283,c=sh(new THREE.Mesh(new THREE.SphereGeometry(.042,6,5),gold2));c.position.set(Math.sin(a)*.18,3.14+.03*Math.cos(a*2),Math.cos(a)*.17);g.add(c)}
  const us=sh(new THREE.Mesh(new THREE.SphereGeometry(.105,12,10),gold2));us.position.y=3.2;g.add(us);
  cyl(g,0,.07,.28,0,0,3.4,0,10,gold);const fl=sh(new THREE.Mesh(new THREE.SphereGeometry(.035,8,6),gold));fl.position.y=3.56;g.add(fl);
  [-1,1].forEach(sd=>{const e=sh(new THREE.Mesh(new THREE.SphereGeometry(.06,8,8),gold));e.scale.set(.35,1.7,.5);e.position.set(.2*sd,2.93,0);g.add(e);
    const ey=new THREE.Mesh(new THREE.SphereGeometry(.02,6,6),dark);ey.scale.set(1.6,.5,.6);ey.position.set(.07*sd,3.0,.175);g.add(ey)});
  const mo=new THREE.Mesh(new THREE.SphereGeometry(.03,6,6),mat(0xa0452a));mo.scale.set(1.6,.45,.6);mo.position.set(0,2.9,.18);g.add(mo);
  // halo
  const ring=sh(new THREE.Mesh(new THREE.TorusGeometry(.55,.03,8,48),gold));ring.position.set(0,3.0,-.25);g.add(ring);
  const disc=new THREE.Mesh(new THREE.CircleGeometry(.53,40),new THREE.MeshBasicMaterial({color:0xf3c85a,transparent:true,opacity:.28,side:THREE.DoubleSide,depthWrite:false}));disc.position.set(0,3.0,-.25);g.add(disc);
  // arms: raised right hand (abhaya), left arm down
  const sh1=new THREE.Vector3(.32,2.32,.02),el=new THREE.Vector3(.5,1.9,.12),ha=new THREE.Vector3(.5,2.3,.3);
  limb(g,sh1,el,.055,gold);limb(g,el,ha,.05,gold);
  const palm=sh(new THREE.Mesh(new THREE.BoxGeometry(.15,.2,.03),gold));palm.position.set(.5,2.42,.31);g.add(palm);
  const th=sh(new THREE.Mesh(new THREE.BoxGeometry(.04,.12,.03),gold));th.position.set(.41,2.36,.31);th.rotation.z=.4;g.add(th);
  limb(g,new THREE.Vector3(-.32,2.32,.02),new THREE.Vector3(-.38,1.6,.1),.055,gold);
  const lh=sh(new THREE.Mesh(new THREE.SphereGeometry(.07,8,8),gold));lh.position.set(-.38,1.52,.12);lh.scale.set(1,1.4,.6);g.add(lh);
  // parasol
  const pa=sh(new THREE.Mesh(new THREE.ConeGeometry(.45,.38,14),new THREE.MeshStandardMaterial({color:0xe6e8ea,roughness:.3,metalness:.5,emissive:0x333333})));pa.position.y=4.05;g.add(pa);
  cyl(g,.015,.015,.5,0xcfd2d4,0,3.78,0,6)})();
(function(){const g=new THREE.Group();g.position.set(6,0,.95);scene.add(g);
  const t=tex(256,170,(c,w,h)=>{c.fillStyle="#b8695b";c.fillRect(0,0,w,h);c.strokeStyle="#e8c9b8";c.lineWidth=2;for(let x=0;x<=w;x+=32){c.beginPath();c.moveTo(x,0);c.lineTo(x,h);c.stroke()}for(let y=0;y<=h;y+=32){c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke()}},[1,1]);
  const f=sh(new THREE.Mesh(new THREE.BoxGeometry(3.6,.06,2.3),new THREE.MeshStandardMaterial({map:t,roughness:.9})));f.position.y=.04;g.add(f);
  bx(g,3.7,.2,.07,0xe9e4d8,0,.14,1.17);bx(g,.07,.2,2.3,0xe9e4d8,-1.82,.14,0);bx(g,.07,.2,2.3,0xe9e4d8,1.82,.14,0);
  })();
// cobra statue (in front of the Buddha)
(function(){const g=new THREE.Group();g.position.set(6,.07,1.2);g.scale.setScalar(.85);scene.add(g);
  const sk=new THREE.MeshStandardMaterial({color:0x8b5b4b,roughness:.8}),sk2=new THREE.MeshStandardMaterial({color:0x9e6d5a,roughness:.8}),hood=new THREE.MeshStandardMaterial({color:0x5c3b3d,roughness:.85});
  cyl(g,.88,.92,.34,0xa68f6a,0,.17,0,32);cyl(g,.8,.8,.03,0xc79a6a,0,.355,0,32);
  const rk=sh(new THREE.Mesh(new THREE.DodecahedronGeometry(.55,1),new THREE.MeshStandardMaterial({color:0x9c9a96,roughness:1,flatShading:true})));rk.position.set(0,.8,-.1);rk.scale.set(1,1.15,.9);g.add(rk);
  [[.62,.13,.52,sk],[.5,.12,.78,sk2],[.37,.11,1.0,sk]].forEach(([R0,t,y,m])=>{const c=sh(new THREE.Mesh(new THREE.TorusGeometry(R0,t,10,36),m));c.rotation.x=Math.PI/2;c.position.y=y;c.scale.set(1,1,.9);g.add(c)});
  for(let i=0;i<14;i++){const u=i/13,r=.16-.05*u,m=sh(new THREE.Mesh(new THREE.SphereGeometry(r,10,8),i%2?sk:sk2));m.position.set(.1*Math.sin(u*3.2),1.05+u*.8,.1*(1-u)-.04*u);g.add(m)}
  const hd=sh(new THREE.Mesh(new THREE.SphereGeometry(.42,20,14),hood));hd.scale.set(1,1.25,.17);hd.position.set(0,2.0,-.08);g.add(hd);
  const fc=sh(new THREE.Mesh(new THREE.SphereGeometry(.17,14,10),sk2));fc.scale.set(.9,.75,1.5);fc.position.set(0,2.3,.2);g.add(fc);
  [-1,1].forEach(sd=>{const fg=new THREE.Mesh(new THREE.ConeGeometry(.018,.1,5),mat(0xf5f0e0));fg.position.set(.05*sd,2.2,.38);fg.rotation.x=Math.PI;g.add(fg);
    const ey=new THREE.Mesh(new THREE.SphereGeometry(.022,6,6),dark);ey.position.set(.08*sd,2.36,.32);g.add(ey)});
  const mo=new THREE.Mesh(new THREE.BoxGeometry(.16,.03,.2),mat(0x3a1f1f));mo.position.set(0,2.25,.36);g.add(mo);
  const tb=bx(g,.45,.2,.28,0x7a5230,0,.46,1.02);
  for(let i=0;i<8;i++){const a=-1.1+i*.31,b=sh(new THREE.Mesh(new THREE.SphereGeometry(.035,6,6),gold));b.position.set(Math.sin(a)*.82,.4,Math.cos(a)*.82);g.add(b)}
  [0xe46a8b,0xf2c744,0xd9443a,0xffffff,0xb77ad8,0xf2c744].forEach((c,i)=>{const f=sh(new THREE.Mesh(new THREE.SphereGeometry(.06,6,6),mat(c)));f.position.set(-.35+i*.14,.42,.7+(i%2)*.06);g.add(f)});
  [-.2,.2].forEach(x=>{const f=new THREE.Mesh(new THREE.ConeGeometry(.025,.08,6),new THREE.MeshBasicMaterial({color:0xffa030}));f.position.set(x,.4,.55);g.add(f)})})();
// sala (thai pavilions)
function sala(x,z,rc,s=1){const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(s);scene.add(g);bx(g,.95,.1,.95,0xd9cdb6,0,.05,0);
  [[-1,-1],[-1,1],[1,-1],[1,1]].forEach(p=>cyl(g,.035,.035,.62,0xf0e6d2,p[0]*.38,.4,p[1]*.38,6));
  const r=sh(new THREE.Mesh(new THREE.ConeGeometry(.85,.55,4),mat(rc)));r.rotation.y=Math.PI/4;r.position.y=.99;g.add(r);cyl(g,0,.03,.22,0xd9a82f,0,1.34,0,5)}
sala(-8.1,1.3,0xa94a38,1.15);sala(1.2,4.4,0xc3592f,1);
// entrance gate
(function(){const g=new THREE.Group();g.position.set(2.8,0,5.2);scene.add(g);const cr=0xe9dfca,rd=0xb4472f;
  [-1.1,1.1].forEach(s=>bx(g,.28,1.25,.28,cr,s,.62,0));
  [-1,1].forEach(s=>{const r=bx(g,3,.07,.62,rd,0,1.42,s*.22);r.rotation.x=-s*.5;r.position.y=1.42});
  bx(g,3.1,.1,.12,cr,0,1.66,0);bx(g,2.2,.14,.3,0xcfc3ac,0,1.12,0);
  [-1,1].forEach(s=>{bx(g,.2,.8,.2,cr,s*2.1,.4,0);const r=bx(g,.95,.06,.5,rd,s*2.1,.9,0);bx(g,1.9,.3,.07,0xe9e4d8,s*3.15,.15,0);bx(g,.16,.5,.16,cr,s*4.1,.25,0)});
  [-1,1].forEach(s=>{for(let i=-3;i<=3;i++)bx(g,.03,.5,.03,0x3b3b3e,s*.6+i*.12-(0),.35,0)});
  [-4.3,4.3].forEach(x=>{cyl(g,.02,.025,1.4,0x777777,x,.7,.3,6);const b=sh(new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),new THREE.MeshBasicMaterial({color:0xfff3c4})));b.position.set(x,1.42,.3);g.add(b)})})();
// sign
(function(){const c=document.createElement("canvas");c.width=512;c.height=170;const x=c.getContext("2d"),t=new THREE.CanvasTexture(c);
  const draw=()=>{x.fillStyle="#5a3d29";x.fillRect(0,0,512,170);x.strokeStyle="#d8c7a8";x.lineWidth=4;x.strokeRect(8,8,496,154);x.fillStyle="#f5ecd8";x.textAlign="center";x.font='700 64px Sarabun,Tahoma,"Leelawadee UI",sans-serif';x.fillText("อุทยานหินเขางู",256,84);x.font='600 44px Sarabun,Tahoma,"Leelawadee UI",sans-serif';x.fillText("ราชบุรี",256,138);t.needsUpdate=true};draw();
  if(document.fonts&&document.fonts.load)document.fonts.load('700 64px Sarabun').then(draw).catch(()=>{});
  const g=new THREE.Group();g.position.set(-1.6,0,5.5);scene.add(g);
  const b=sh(new THREE.Mesh(new THREE.BoxGeometry(1.7,.56,.06),[mat(0x4a3322),mat(0x4a3322),mat(0x4a3322),mat(0x4a3322),new THREE.MeshStandardMaterial({map:t,roughness:.7}),mat(0x4a3322)]));b.position.y=.62;g.add(b);
  [-.75,.75].forEach(s=>cyl(g,.03,.03,.4,0x3a2a1c,s,.2,0,6))})();

// ---------- controls / ui ----------
let fly=null;const ease=t=>t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2;
function flyTo(p,t){fly={t0:performance.now(),d:900,p0:camera.position.clone(),t0v:controls.target.clone(),p1:p,t1:t}}
controls.addEventListener("start",()=>{fly=null});
const V={front:[0,8.5,25],left:[-25,8.5,0],right:[25,8.5,0],back:[0,8.5,-25],top:[0,38,.01]};
document.querySelectorAll("[data-v]").forEach(b=>b.onclick=()=>flyTo(new THREE.Vector3(...V[b.dataset.v]),new THREE.Vector3(0,.3,0)));
document.getElementById("reset").onclick=()=>flyTo(HOME.p.clone(),HOME.t.clone());
const ab=document.getElementById("auto");ab.onclick=()=>{controls.autoRotate=!controls.autoRotate;ab.classList.toggle("on",controls.autoRotate)};
addEventListener("resize",()=>{camera.aspect=W()/H();camera.updateProjectionMatrix();renderer.setSize(W(),H())});
(function loop(){requestAnimationFrame(loop);if(!window.__on3d)return;
  if(fly){const k=Math.min(1,(performance.now()-fly.t0)/fly.d),e=ease(k);camera.position.lerpVectors(fly.p0,fly.p1,e);controls.target.lerpVectors(fly.t0v,fly.t1,e);if(k>=1)fly=null}
  wTex.offset.x+=.00025;wTex.offset.y+=.00012;controls.update();renderer.render(scene,camera);if(window.__hs)window.__hs(camera)})();
window.__scene={THREE,camera,controls,flyTo};

}
